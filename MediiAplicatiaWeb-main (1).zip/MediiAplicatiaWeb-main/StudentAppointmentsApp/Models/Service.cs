﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StudentAppointmentsApp.Models
{
    public class Service
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Description is required.")]
        [StringLength(1000, ErrorMessage = "Description cannot exceed 1000 characters.")]
        public string Description { get; set; }

        // Adaugă UserId pentru a identifica cine a creat serviciul
        public string? UserId { get; set; }

        // Relație cu entitatea User
        [ForeignKey("UserId")]
        public User? Creator { get; set; }
    }
}
