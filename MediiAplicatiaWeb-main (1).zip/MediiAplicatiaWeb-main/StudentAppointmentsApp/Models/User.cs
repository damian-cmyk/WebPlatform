﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace StudentAppointmentsApp.Models
{
    // Clasa User moștenește IdentityUser pentru a folosi funcționalitățile integrate
    public class User : IdentityUser
    {
        [Required(ErrorMessage = "Name is required.")]
        [StringLength(50, ErrorMessage = "Name cannot exceed 50 characters.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Role is required.")]
        [EnumDataType(typeof(UserRole), ErrorMessage = "Role must be either Student or Client.")]
        public UserRole Role { get; set; }
    }

    // Enum pentru roluri
    public enum UserRole
    {
        Student,
        Client
    }
}
