﻿using System.ComponentModel.DataAnnotations;

namespace StudentAppointmentsApp.Models
{
    public class Feedback
    {
        public int ID { get; set; }

        // Studentul care primește feedback
        public string? StudentID { get; set; }
        public User? Student { get; set; }

        // Clientul care creează feedback-ul
        public string? ClientID { get; set; }
        public User? Client { get; set; }

        [Required(ErrorMessage = "Review is required.")]
        [StringLength(500, ErrorMessage = "Review cannot exceed 500 characters.")]
        public string Review { get; set; }

        [Required(ErrorMessage = "Rating is required.")]
        [Range(1, 5, ErrorMessage = "Rating must be between 1 and 5.")]
        public int Rating { get; set; }
    }
}
