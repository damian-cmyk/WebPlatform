﻿using System.ComponentModel.DataAnnotations;

namespace StudentAppointmentsApp.Models
{
    public class Schedule
    {
        public int ID { get; set; }

        public User? Student { get; set; }

        [Required(ErrorMessage = "Available Date is required.")]
        [DataType(DataType.Date, ErrorMessage = "Invalid date format.")]
        public DateTime AvailableDate { get; set; }

        [Required(ErrorMessage = "Start Time is required.")]
        [DataType(DataType.Time, ErrorMessage = "Invalid time format.")]
        public TimeSpan StartTime { get; set; }

        [Required(ErrorMessage = "End Time is required.")]
        [DataType(DataType.Time, ErrorMessage = "Invalid time format.")]
        public TimeSpan EndTime { get; set; }
    }
}
