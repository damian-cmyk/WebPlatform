﻿using System.ComponentModel.DataAnnotations;

namespace StudentAppointmentsApp.Models
{
    public class Appointment
    {
        public int ID { get; set; }

        public string? StudentID { get; set; }
        public User? Student { get; set; }

        public string? ClientID { get; set; }
        public User? Client { get; set; }

        public DateTime Date { get; set; }

        public string Status { get; set; }
    }
}
