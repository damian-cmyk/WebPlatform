﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace StudentAppointmentsApp.Migrations
{
    /// <inheritdoc />
    public partial class newFeedback : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Feedbacks_Appointments_AppointmentID",
                table: "Feedbacks");

            migrationBuilder.DropIndex(
                name: "IX_Feedbacks_AppointmentID",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "AppointmentID",
                table: "Feedbacks");

            migrationBuilder.AddColumn<string>(
                name: "StudentID",
                table: "Feedbacks",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_Feedbacks_StudentID",
                table: "Feedbacks",
                column: "StudentID");

            migrationBuilder.AddForeignKey(
                name: "FK_Feedbacks_AspNetUsers_StudentID",
                table: "Feedbacks",
                column: "StudentID",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Feedbacks_AspNetUsers_StudentID",
                table: "Feedbacks");

            migrationBuilder.DropIndex(
                name: "IX_Feedbacks_StudentID",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "StudentID",
                table: "Feedbacks");

            migrationBuilder.AddColumn<int>(
                name: "AppointmentID",
                table: "Feedbacks",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Feedbacks_AppointmentID",
                table: "Feedbacks",
                column: "AppointmentID");

            migrationBuilder.AddForeignKey(
                name: "FK_Feedbacks_Appointments_AppointmentID",
                table: "Feedbacks",
                column: "AppointmentID",
                principalTable: "Appointments",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
