﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace StudentAppointmentsApp.Migrations
{
    /// <inheritdoc />
    public partial class newFeedBack3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ClientID",
                table: "Feedbacks",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Feedbacks_ClientID",
                table: "Feedbacks",
                column: "ClientID");

            migrationBuilder.AddForeignKey(
                name: "FK_Feedbacks_AspNetUsers_ClientID",
                table: "Feedbacks",
                column: "ClientID",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Feedbacks_AspNetUsers_ClientID",
                table: "Feedbacks");

            migrationBuilder.DropIndex(
                name: "IX_Feedbacks_ClientID",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "ClientID",
                table: "Feedbacks");
        }
    }
}
