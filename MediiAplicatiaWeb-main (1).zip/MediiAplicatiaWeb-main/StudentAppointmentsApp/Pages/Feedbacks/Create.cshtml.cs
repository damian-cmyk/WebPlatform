﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentAppointmentsApp.Models;

namespace StudentAppointmentsApp.Pages_Feedbacks
{
    public class CreateModel : PageModel
    {
        private readonly StudentAppointmentsWeb.Data.StudentAppointmentsContext _context;
        private readonly UserManager<User> _userManager;

        public CreateModel(StudentAppointmentsWeb.Data.StudentAppointmentsContext context, UserManager<User> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IActionResult OnGet()
        {
            var students = _context.Users
    .Where(u => u is User)
    .Cast<User>(); 

ViewData["StudentID"] = new SelectList(students, "Id", "Name");

            return Page();
        }

        [BindProperty]
        public Feedback Feedback { get; set; } = default!;

        [BindProperty]
        public List<string> ValidationErrors { get; set; } = new List<string>();

        public async Task<IActionResult> OnPostAsync()
        {
            // Verificăm dacă modelul este valid
            if (!ModelState.IsValid)
            {
                // Debugging: Afișează erorile din ModelState
                foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                {
                    Console.WriteLine($"Field: {error.ErrorMessage}");
                }
                return Page();
            }

            // Obține ID-ul utilizatorului logat
            var clientId = _userManager.GetUserId(User);

            if (string.IsNullOrEmpty(clientId))
            {
                // Dacă utilizatorul logat nu este găsit, returnează o eroare
                ModelState.AddModelError(string.Empty, "Nu s-a putut identifica utilizatorul logat.");
                return Page();
            }

            // Setăm ClientID automat pentru feedback
            Feedback.ClientID = clientId;

            // Adaugă feedback-ul în baza de date
            _context.Feedbacks.Add(Feedback);

            // Salvează modificările
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Debugging: Afișează eroarea în consolă
                Console.WriteLine($"Database save error: {ex.Message}");
                ModelState.AddModelError(string.Empty, "A apărut o eroare la salvarea datelor.");
                return Page();
            }

            // Redirecționăm la pagina Index
            return RedirectToPage("./Index");
        }
    }
}
