﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using StudentAppointmentsApp.Models;
using StudentAppointmentsWeb.Data;

namespace StudentAppointmentsApp.Pages_Feedbacks
{
    public class EditModel : PageModel
    {
        private readonly StudentAppointmentsWeb.Data.StudentAppointmentsContext _context;

        public EditModel(StudentAppointmentsWeb.Data.StudentAppointmentsContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Feedback Feedback { get; set; } = default!;

        [BindProperty]
        public List<string> ValidationErrors { get; set; } = new List<string>();

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Feedback = await _context.Feedbacks
                .Include(f => f.Student) // Include relația cu Student pentru afișarea numelui
                .FirstOrDefaultAsync(m => m.ID == id);

            if (Feedback == null)
            {
                return NotFound();
            }

            // Populate dropdown with students
            var students = _context.Users
                .Where(u => u is User)
                .Cast<User>();

            ViewData["StudentID"] = new SelectList(students, "Id", "Name", Feedback.StudentID);

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                // Debugging: Captură erori
                foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                {
                    ValidationErrors.Add(error.ErrorMessage);
                }

                // Reload dropdown in case of error
                var students = _context.Users
                    .Where(u => u is User)
                    .Cast<User>();

                ViewData["StudentID"] = new SelectList(students, "Id", "Name", Feedback.StudentID);

                return Page();
            }

            // Obține entitatea curentă din baza de date
            var existingFeedback = await _context.Feedbacks
                .AsNoTracking() // Asigură-te că entitatea originală nu este urmărită
                .FirstOrDefaultAsync(f => f.ID == Feedback.ID);

            if (existingFeedback == null)
            {
                return NotFound();
            }

            // Păstrează valoarea originală a ClientID dacă este nul în formular
            Feedback.ClientID = existingFeedback.ClientID;

            _context.Attach(Feedback).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!FeedbackExists(Feedback.ID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }


        private bool FeedbackExists(int id)
        {
            return _context.Feedbacks.Any(e => e.ID == id);
        }
    }
}
