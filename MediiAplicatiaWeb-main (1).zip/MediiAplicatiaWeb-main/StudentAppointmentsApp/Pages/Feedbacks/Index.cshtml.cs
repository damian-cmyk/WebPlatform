﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using StudentAppointmentsApp.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;


namespace StudentAppointmentsApp.Pages_Feedbacks
{
    public class IndexModel : PageModel
    {
        private readonly StudentAppointmentsWeb.Data.StudentAppointmentsContext _context;

        public IndexModel(StudentAppointmentsWeb.Data.StudentAppointmentsContext context)
        {
            _context = context;
        }

        public List<Feedback> Feedback { get; set; } = new List<Feedback>();
        public string Filter { get; set; } = string.Empty;

        public async Task OnGetAsync(string filter = "")
        {
            Filter = filter;

            var query = _context.Feedbacks
                .Include(f => f.Student)
                .AsQueryable(); // Asigură compatibilitatea cu Where

            // Aplică filtrarea dacă există un nume
            if (!string.IsNullOrEmpty(Filter))
            {
                query = query.Where(f => f.Student != null && f.Student.Name.Contains(Filter));
            }

            Feedback = await query.ToListAsync();

        }

        [BindProperty]
        public Feedback FeedbackInput { get; set; } = new Feedback();

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Obține ID-ul utilizatorului conectat
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId == null)
            {
                return Unauthorized();
            }

            // Setează ClientID cu ID-ul utilizatorului conectat
            FeedbackInput.ClientID = userId;

            // Adaugă feedback-ul și salvează în baza de date
            _context.Feedbacks.Add(FeedbackInput);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            // Găsește feedback-ul după ID
            var feedback = await _context.Feedbacks.FindAsync(id);

            if (feedback == null)
            {
                return NotFound();
            }

            // Verifică dacă utilizatorul curent este cel care a creat feedback-ul
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (feedback.ClientID != userId)
            {
                return Forbid();
            }

            // Șterge feedback-ul
            _context.Feedbacks.Remove(feedback);
            await _context.SaveChangesAsync();

            // Redirecționează înapoi la pagina de Index
            return RedirectToPage("./Index");
        }

    }
}
