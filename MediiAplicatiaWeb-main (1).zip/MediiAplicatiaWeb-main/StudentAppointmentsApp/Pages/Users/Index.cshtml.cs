﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using StudentAppointmentsWeb.Data;
using StudentAppointmentsApp.Models;

namespace StudentAppointmentsApp.Pages_Users
{
    public class IndexModel : PageModel
    {
        private readonly StudentAppointmentsContext _context;

        public IndexModel(StudentAppointmentsContext context)
        {
            _context = context;
        }

        public IList<User> PaginatedUsers { get; set; }
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
        public const int PageSize = 9;

        public async Task OnGetAsync(int page = 1)
        {
            CurrentPage = page;
            var totalUsers = await _context.Users.CountAsync();
            TotalPages = (int)Math.Ceiling(totalUsers / (double)PageSize);

            PaginatedUsers = await _context.Users
           .OfType<User>() // Asigură-te că selectezi doar instanțe ale clasei `User`
            .OrderBy(u => u.Name)
            .Skip((CurrentPage - 1) * PageSize)
            .Take(PageSize)
            .ToListAsync();

        }
    }
}
