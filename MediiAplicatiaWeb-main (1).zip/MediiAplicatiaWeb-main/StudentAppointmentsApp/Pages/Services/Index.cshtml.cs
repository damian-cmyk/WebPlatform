﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using StudentAppointmentsApp.Models;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace StudentAppointmentsApp.Pages_Services
{
    public class IndexModel : PageModel
    {
        private readonly StudentAppointmentsWeb.Data.StudentAppointmentsContext _context;

        public IndexModel(StudentAppointmentsWeb.Data.StudentAppointmentsContext context)
        {
            _context = context;
        }

        public List<Service> Services { get; set; } = new List<Service>();
        public string Filter { get; set; } = string.Empty;

        public async Task OnGetAsync(string filter = "")
        {
            Filter = filter;

            // Filtrare servicii
            var query = _context.Services.AsQueryable();

            if (!string.IsNullOrEmpty(Filter))
            {
                query = query.Where(s => s.Name.Contains(Filter));
            }

            Services = await query.ToListAsync();
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            // Obține ID-ul utilizatorului conectat
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized();
            }

            // Găsește serviciul după ID
            var service = await _context.Services.FirstOrDefaultAsync(s => s.ID == id);

            if (service == null)
            {
                return NotFound();
            }

            // Verifică dacă utilizatorul conectat este creatorul serviciului
            if (service.UserId != userId)
            {
                return Forbid();
            }

            // Șterge serviciul
            _context.Services.Remove(service);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
