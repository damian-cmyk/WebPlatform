﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using StudentAppointmentsApp.Models;
using StudentAppointmentsWeb.Data;

namespace StudentAppointmentsApp.Pages_Services
{
    public class CreateModel : PageModel
    {
        private readonly StudentAppointmentsWeb.Data.StudentAppointmentsContext _context;

        public CreateModel(StudentAppointmentsWeb.Data.StudentAppointmentsContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Service Service { get; set; } = default!;

        // For more information, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Obține ID-ul utilizatorului conectat
            var userId = User.FindFirstValue(System.Security.Claims.ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userId))
            {
                // Dacă utilizatorul nu este autentificat, returnăm eroare
                return Unauthorized();
            }

            // Setează UserId pentru serviciu
            Service.UserId = userId;

            // Adaugă serviciul în baza de date
            _context.Services.Add(Service);
            await _context.SaveChangesAsync();

            // Redirecționează la pagina Index
            return RedirectToPage("./Index");
        }

    }
}
