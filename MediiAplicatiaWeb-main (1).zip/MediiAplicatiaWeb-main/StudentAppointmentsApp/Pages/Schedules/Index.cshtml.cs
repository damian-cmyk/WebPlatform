﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using StudentAppointmentsApp.Models;
using StudentAppointmentsWeb.Data;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace StudentAppointmentsApp.Pages_Schedules
{
    public class IndexModel : PageModel
    {
        private readonly StudentAppointmentsContext _context;

        public IndexModel(StudentAppointmentsContext context)
        {
            _context = context;
        }

        public List<Schedule> Schedules { get; set; } = new List<Schedule>();

        [BindProperty(SupportsGet = true)]
        public string Filter { get; set; } = string.Empty;

        public async Task OnGetAsync()
        {
            // Preluăm toate programările și includem relația cu Student
            var query = _context.Schedules
                .Include(s => s.Student)
                .AsQueryable();

            // Aplicăm filtrarea dacă există un criteriu de căutare
            if (!string.IsNullOrEmpty(Filter))
            {
                query = query.Where(s => s.Student != null && s.Student.Name.Contains(Filter));
            }

            // Returnăm rezultatele filtrate
            Schedules = await query.ToListAsync();
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            // Găsește programarea (schedule) după ID
            var schedule = await _context.Schedules.FindAsync(id);

            if (schedule == null)
            {
                return NotFound(); // Dacă nu este găsită, returnează 404
            }

            // Verifică dacă utilizatorul curent este studentul care a creat schedule-ul
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            // Șterge programarea din baza de date
            _context.Schedules.Remove(schedule);
            await _context.SaveChangesAsync();

            // Redirecționează către pagina Index pentru a reîncărca lista
            return RedirectToPage("./Index");
        }

    }
}
 