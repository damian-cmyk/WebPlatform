﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using StudentAppointmentsApp.Models;
using StudentAppointmentsWeb.Data;
using System.Threading.Tasks;

namespace StudentAppointmentsApp.Pages_Schedules
{
    public class CreateModel : PageModel
    {
        private readonly StudentAppointmentsContext _context;
        private readonly UserManager<User> _userManager;

        public CreateModel(StudentAppointmentsContext context, UserManager<User> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [BindProperty]
        public Schedule Schedule { get; set; }

        public IActionResult OnGet()
        {
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            // Obține ID-ul utilizatorului conectat
            var userId = _userManager.GetUserId(User);
            var student = await _userManager.FindByIdAsync(userId);

            // Asociază programul cu utilizatorul conectat
            Schedule.Student = student;

            // Verifică dacă modelul este valid
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Schedules.Add(Schedule);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
