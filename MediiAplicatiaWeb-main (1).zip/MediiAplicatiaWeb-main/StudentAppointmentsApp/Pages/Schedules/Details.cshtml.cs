using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using StudentAppointmentsApp.Models;
using StudentAppointmentsWeb.Data;

namespace StudentAppointmentsApp.Pages_Schedules
{
    public class DetailsModel : PageModel
    {
        private readonly StudentAppointmentsWeb.Data.StudentAppointmentsContext _context;

        public DetailsModel(StudentAppointmentsWeb.Data.StudentAppointmentsContext context)
        {
            _context = context;
        }

        public Schedule Schedule { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var schedule = await _context.Schedules.FirstOrDefaultAsync(m => m.ID == id);

            if (schedule is not null)
            {
                Schedule = schedule;

                return Page();
            }

            return NotFound();
        }
    }
}
