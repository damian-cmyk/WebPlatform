﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using StudentAppointmentsApp.Models;
using StudentAppointmentsWeb.Data;

namespace StudentAppointmentsApp.Pages_Appointments
{
    public class IndexModel : PageModel
    {
        private readonly StudentAppointmentsContext _context;
        private readonly UserManager<User> _userManager;

        public IndexModel(StudentAppointmentsContext context, UserManager<User> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public List<Appointment> Appointments { get; set; } = new List<Appointment>();
        [BindProperty(SupportsGet = true)]
        public string Filter { get; set; } = string.Empty; // Proprietate pentru filtrare

        public async Task OnGetAsync()
        {
            // Obține programările, inclusiv informațiile despre Student și Client
            var query = _context.Appointments
                .Include(a => a.Student)
                .Include(a => a.Client)
                .OrderBy(a => a.Date);

            // Aplică filtrul dacă există
            if (!string.IsNullOrEmpty(Filter))
            {
                query = query.Where(a => a.Status == Filter).OrderBy(a => a.Date);
            }

            Appointments = await query.ToListAsync();
        }

        public async Task<IActionResult> OnPostReserveAsync(int id)
        {
            // Verifică dacă utilizatorul logat este client
            var userId = _userManager.GetUserId(User);
            var user = await _userManager.FindByIdAsync(userId);

            if (user == null || user.Role != UserRole.Client)
            {
                return Forbid();
            }

            // Găsește programarea și setează ClientID la utilizatorul logat
            var appointment = await _context.Appointments.FindAsync(id);
            if (appointment == null || appointment.ClientID != null)
            {
                return NotFound();
            }

            appointment.ClientID = userId;

            // Actualizează programarea în baza de date
            _context.Appointments.Update(appointment);
            await _context.SaveChangesAsync();

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            // Găsește programarea după ID
            var appointment = await _context.Appointments.FindAsync(id);

            if (appointment == null)
            {
                return NotFound();
            }

            // Verifică dacă utilizatorul logat este studentul care a creat programarea
            var userId = _userManager.GetUserId(User);
            if (appointment.StudentID != userId)
            {
                return Forbid(); // Nu permite ștergerea dacă utilizatorul nu este creatorul
            }

            // Șterge programarea
            _context.Appointments.Remove(appointment);
            await _context.SaveChangesAsync();

            return RedirectToPage();
        }

    }
}
