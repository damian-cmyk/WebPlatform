﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using StudentAppointmentsApp.Models;
using StudentAppointmentsWeb.Data;

namespace StudentAppointmentsApp.Pages_Appointments
{
    public class CreateModel : PageModel
    {
        private readonly StudentAppointmentsWeb.Data.StudentAppointmentsContext _context;
        private readonly UserManager<User> _userManager;

        public CreateModel(StudentAppointmentsWeb.Data.StudentAppointmentsContext context, UserManager<User> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Appointment Appointment { get; set; } = default!;

        // For more information, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            // Verificăm dacă modelul este valid
            if (!ModelState.IsValid)
            {
                // Debugging: Afișează erorile din ModelState
                foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                {
                    Console.WriteLine($"Field: {error.ErrorMessage}");
                }
                return Page();
            }

            // Obține ID-ul utilizatorului logat (Student)
            var studentId = _userManager.GetUserId(User);

            if (string.IsNullOrEmpty(studentId))
            {
                // Dacă utilizatorul logat nu este găsit, returnează o eroare
                ModelState.AddModelError(string.Empty, "Nu s-a putut identifica utilizatorul logat.");
                return Page();
            }

            // Setăm StudentID automat pentru programare
            Appointment.StudentID = studentId;

            // ClientID rămâne null, programarea va fi disponibilă pentru clienți
            Appointment.ClientID = null;

            // Adaugă programarea în baza de date
            _context.Appointments.Add(Appointment);

            // Salvează modificările
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Debugging: Afișează eroarea în consolă
                Console.WriteLine($"Database save error: {ex.Message}");
                ModelState.AddModelError(string.Empty, "A apărut o eroare la salvarea datelor.");
                return Page();
            }

            // Redirecționăm la pagina Index sau alta pagină relevantă
            return RedirectToPage("./Index");
        }



    }
}
