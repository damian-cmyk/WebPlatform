﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using StudentAppointmentsApp.Models;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace StudentAppointmentsApp.Pages.Appointments
{
    [Authorize]
    public class MyAppointmentsModel : PageModel
    {
        private readonly StudentAppointmentsWeb.Data.StudentAppointmentsContext _context;

        public MyAppointmentsModel(StudentAppointmentsWeb.Data.StudentAppointmentsContext context)
        {
            _context = context;
        }

        public List<Appointment> Appointments { get; set; } = new List<Appointment>();

        public async Task<IActionResult> OnGetAsync()
        {
            // Obține ID-ul utilizatorului conectat
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized();
            }

            // Selectează programările utilizatorului (ca student sau client)
            Appointments = await _context.Appointments
                .Include(a => a.Student)
                .Include(a => a.Client)
                .Where(a => a.StudentID == userId || a.ClientID == userId)
                .ToListAsync();

            return Page();
        }
    }
}
