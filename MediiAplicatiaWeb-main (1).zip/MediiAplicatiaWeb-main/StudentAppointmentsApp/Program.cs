using StudentAppointmentsWeb.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using StudentAppointmentsApp.Models;

var builder = WebApplication.CreateBuilder(args);

// Adăugarea serviciilor pentru sesiuni
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Durata sesiunii
    options.Cookie.HttpOnly = true; // Asigură securitatea cookie-urilor
    options.Cookie.IsEssential = true; // Necesitatea cookie-urilor
});

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Identity/Account/Login";
    options.AccessDeniedPath = "/Identity/Account/AccessDenied";
});


// Adăugarea serviciilor pentru Razor Pages
builder.Services.AddRazorPages();

// Configurarea DbContext cu SQL Server
builder.Services.AddDbContext<StudentAppointmentsContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Adăugarea Identity cu setări pentru autentificare
builder.Services.AddDefaultIdentity<User>(options =>
{
    options.SignIn.RequireConfirmedAccount = false;
})
.AddEntityFrameworkStores<StudentAppointmentsContext>();


var app = builder.Build();

// Configurarea pipeline-ului middleware
app.UseStaticFiles();
app.UseRouting();
app.UseSession();         // Middleware pentru sesiuni
app.UseAuthentication();  // Middleware pentru autentificare
app.UseAuthorization();   // Middleware pentru autorizare

app.MapRazorPages(); // Maparea paginilor Razor

app.Run();
